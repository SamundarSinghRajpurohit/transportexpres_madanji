<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct()
	{
		//die("asdasd");
		parent::__construct();
		
		$this->load->helper('url');
		$this->load->helper('download');
        
		$this->load->helper('custom_helper');
		//check_p("asd");
		$set['upload_path']='./resources/images/';
		$set['allowed_types']='png|jpg|gif|jpeg';
		$this->load->library('upload',$set);    
		$this->load->model('Admin/MainModel','mm');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->library('excel');

	}
	public function index()
	{
	    if(!$this->session->AdminId)
		{
			$this->load->view('Admin/login');
		}
		else
		{
    	    $data=$this->index_header();
    	 //  $this->CreateExcel($data);
    	    $this->index_view($data);
    	}
    }
    public function logout()
	{
	    $this->session->sess_destroy();
	    $this->load->view('Admin/login');
	    
	}
	public function CreateCSVDifferent($data1='')
	{
	        $tblName="tbl".$data1;
	    
	}
	
	public function MemberCardDifferent($data1='')
	{
	
	  // $keyName="Sales";
	 
	   $data['pageLink']="Admin/MemberCardDetail";
	   $data['pageName']="MemberCardDetail";
	   $data['page']="MemberCardDetail";
	   $tblName="tblcashtransaction";
	   $data['Fields']=$this->mm->get_table_heading($tblName);
 	   $data['OriginalFields']=$data['Fields'];
 	
	   //  check_p("asd");
	   
	  $data=$this->new_comman_header_different($data,'');
	 
	          //  check_p("asd");
	   $this->new_comman_view_different($data);
	    
	}
	public function AccountingDifferent($data1='')
	{
	
	  // $keyName="Sales";
	 
	   $data['pageLink']="Admin/Accounting";
	   $data['pageName']="Accounting";
	   $data['page']="Accounting";
	   $tblName="tblcashtransaction";
	   $data['Fields']=$this->mm->get_table_heading($tblName);
 	   $data['OriginalFields']=$data['Fields'];
 	   $tblName1="tblbanktransaction";
 	   $data['BankFields']=$this->mm->get_table_heading($tblName1);
	   $data['BankOriginalFields']=$data['BankFields'];
	   //  check_p("asd");
	   
	  $data=$this->new_comman_header_different($data,'');
	 
	          //  check_p("asd");
	   $this->new_comman_view_different($data);
	    
	}
	
	public function LedgerDifferent($data1='')
	{
	
	  // $keyName="Sales";
	 
	   $data['pageLink']="Admin/Ledger";
	   $data['pageName']="Ledger";
	   $data['page']="Ledger";
	   $tblName="tblledger";
	   $data['Fields']=$this->mm->get_table_heading($tblName);
 	   $data['OriginalFields']=$data['Fields'];
 	
	   //  check_p("asd");
	   
	  $data=$this->new_comman_header_different($data,'');
	 
	          //  check_p("asd");
	   $this->new_comman_view_different($data);
	    
	}
	public function BankLedgerDifferent($data1='')
	{
	
	  // $keyName="Sales";
	 
	   $data['pageLink']="Admin/BankLedger";
	   $data['pageName']="BankLedger";
	   $data['page']="Ledger";
	   $tblName="tblbankledger";
	   $data['Fields']=$this->mm->get_table_heading($tblName);
 	   $data['OriginalFields']=$data['Fields'];
 	
	   //  check_p("asd");
	   
	  $data=$this->new_comman_header_different($data,'');
	 
	          //  check_p("asd");
	   $this->new_comman_view_different($data);
	    
	}
	public function CashLedgerDifferent($data1='')
	{
	
	  // $keyName="Sales";
	 
	   $data['pageLink']="Admin/CashLedger";
	   $data['pageName']="CashLedger";
	   $data['page']="Ledger";
	   $tblName="tblcashledger";
	   $data['Fields']=$this->mm->get_table_heading($tblName);
 	   $data['OriginalFields']=$data['Fields'];
 	
	   //  check_p("asd");
	   
	  $data=$this->new_comman_header_different($data,'');
	 
	          //  check_p("asd");
	   $this->new_comman_view_different($data);
	    
	}
	public function BillPrintDifferent($tblName,$id)
	{
	   // check_p($tblName);
	   $data=$this->new_comman_header_different('tbl'.strtolower($tblName));
	   $data['pageLink']="Admin/BillView";
	   $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	   $whereData=array($tableIdName=>$id);
	   $data['BillData']=$this->mm->get_a_data_join($tblName,$whereData);
	   $TypeData=$this->mm->get_a_data('tbltype','TypeId',$data['BillData'][0]->TypeId);
	   $data['TypeData']=$TypeData;
	   $HSNData=$this->mm->get_a_data('tblhsn','HsnId',$data['TypeData'][0]->HsnId);
	   $data['HsnData']=$HSNData;
	   $this->new_comman_view_different($data);
	    
	}
	public function CreateCSVDemoDifferent($data1='')
	{       
	        $tblName="tbl".$data1;
	        $data[]=$this->mm->get_table_heading($tblName);
	        //check_p($data);
	        $data=replace_id_name($data[0]);
	        $data=remove_first_last_field($data);
	        //$data=remove_last_field()
	        $data=array($data);
	       
 	        $fileName=$data1.".csv";
            header("Content-type: text/csv");
            header("Content-Disposition: attachment; filename=".$fileName);
            header("Pragma: no-cache");
            header("Expires: 0");
           
            $handle = fopen('php://output', 'w');
                 
            foreach ($data as $data) {
                fputcsv($handle, $data);
            }
           // check_p($data);
            fclose($handle);
            exit;
   	}
   	public function ReportDifferent()
   	{
   	     // check_p($tblName);
	   $keyName="Sales";
	   $data=$this->new_comman_header_different('tbl'.strtolower($keyName));
	   $data['pageLink']="Admin/ReportView";
	   $data['pageName']="Report";
	   if($this->input->post('FromDate')&&$this->input->post('ToDate'))
	   {
	       
	   $fromDate=$this->input->post('FromDate');
	   $toDate=$this->input->post('ToDate');
	   $tblName='tblsales';
	   $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	   //$whereData=array($tableIdName=>$id);
	   $data['BillData']=$this->mm->get_all_data_join_order_by($tblName,'SalesAirInovice');
	  /* $TypeData=$this->mm->get_a_data('tbltype','TypeId',$data['BillData'][0]->TypeId);
	   check_p($TypeData);
	   $data['BillData']=array_merge($data['BillData'],$TypeData);
	   $HSNData=$this->mm->get_a_data('tblhsn','HsnId',$data['TypeData'][0]->HsnId);
	   $data['HsnData']=$HSNData;*/
	  
	    //check_p($HSNData);
	   $begin = new DateTime( $fromDate);
        $end   = new DateTime( $toDate );
        $FromToDate=array();
        $FromToDate2=array();
        
        for($i = $begin; $i <= $end; $i->modify('+1 day')){
         
           $FromToDate[]=$i->format('d-m-Y');  //01-02-2019
          
           $FromToDate2[]=$i->format('j-n-y'); //1-5-19
           $FromToDate3[]=$i->format('d-m-y'); //01-05-19
           $FromToDate7[]=$i->format('j-n-Y'); //1-5-2019
           $FromToDate8[]=$i->format('m-d-Y');  //25-02-2019
           
           
          
           $FromToDate4[]=$i->format('j/n/Y'); //1/5/2019
           $FromToDate8[]=$i->format('j/n/y'); //1/5/19
           $FromToDate5[]=$i->format('d/m/Y'); //01/05/2019
           $FromToDate6[]=$i->format('d/m/y'); //05/05/19
           $FromToDate9[]=$i->format('m/d/Y'); //05/05/19
           $FromToDate10[]=$i->format('n/j/Y'); //2/13/19
           
           
           
        //   echo $i->format('d-m-Y')."<br>";
        }    
        
        //check_p($data['BillData']);
    
	    $excelColumn=array('SalesAirInovice','CustomerName','SalesDate','SalesPassenger','SalesGrossTotal','SalesProcessingCharges','SalesCGST','SalesSGST','SalesIGST','SalesPlaceOfSupply','CustomerGSTNo');
	    $whereDate='PurchaseTaxDate';
	    $whereGSTCol='CustomerGSTNo';
	    $i=0;
	    $reportData;
    	$customerHavingGST=array();
    	$customerNotHavingGST=array();
    	$customerDetail=array();
    	for($i=0;$i<sizeof($data['BillData']);$i++)
    	{
    	    foreach( $data['BillData'][$i] as $salesKey=>$salesData)
    	    {  
    	        if(in_array($salesKey,$excelColumn)&&
    	          ((in_array($data['BillData'][$i]->$whereDate,$FromToDate))
    	        ||((in_array($data['BillData'][$i]->$whereDate,$FromToDate2)))
    	        ||((in_array($data['BillData'][$i]->$whereDate,$FromToDate3)))
    	        ||((in_array($data['BillData'][$i]->$whereDate,$FromToDate4)))
    	        ||((in_array($data['BillData'][$i]->$whereDate,$FromToDate5)))
    	        ||((in_array($data['BillData'][$i]->$whereDate,$FromToDate6)))
    	        ||((in_array($data['BillData'][$i]->$whereDate,$FromToDate7)))
    	        ||((in_array($data['BillData'][$i]->$whereDate,$FromToDate8)))
    	        ||((in_array($data['BillData'][$i]->$whereDate,$FromToDate9)))
    	        ||((in_array($data['BillData'][$i]->$whereDate,$FromToDate10)))
    	        
    	        ))
    	        {   
    	            /*if($data['BillData'][$i]->$whereGSTCol)
    	            {
    	             $customerHavingGST[$i][$salesKey]= $salesData;
    	            }
    	            else
    	            {
    	             $customerNotHavingGST[$i][$salesKey]= $salesData;
    	            }*/
    	            $customerDetail[$i][$salesKey]=$salesData;
    	            
    	        }
    	   }
    	      //for new array report Data
    	}
        //	check_p( $customerDetail);
	    
	    $fileName=$fromDate."-".$toDate.".csv";
        header("Content-type: text/csv");
        header("Content-Disposition: attachment; filename=".$fileName);
        header("Pragma: no-cache");
        header("Expires: 0");
       
        $handle = fopen('php://output', 'w');
        $excelColumnHeading=array(array('InvoiceNo','CustomerName','SalesDate','SalesPlaceOfSupply','SalesGrossTotal','SalesProcessingCharges','SalesCGST','SalesSGST','SalesIGST','Passenger','CustomerGSTNo'));
	    //$excelColumnHeading=array(0=>'PurchaseId',1=>'PurchaseTaxDate',2=>'CustomerName',3=>'SalesPassenger',4=>'SalesGrossTotal',5=>'SalesProcessingCharges',6=>'SalesCGST',7=>'SalesSGST',8=>'SalesIGST',9=>'CustomerGSTNo');
        foreach ($excelColumnHeading as $data) {
                fputcsv($handle, $data);
            }
        //$allCustom =array_merge($customerHavingGST,$customerNotHavingGST);
        if($customerDetail)
        {
             
    
            foreach ($customerDetail as $data) {
                fputcsv($handle, $data);
            }
        }
        fclose($handle);
        exit;
   	
	   }
	   $this->new_comman_view_different($data);
   	}
    public function login()
	{
		$this->form_validation->set_rules('Admin_Email','EmailID','required');
		$this->form_validation->set_rules('Admin_Password','Password','required');
		if($this->form_validation->run()==FALSE)
		{
			$this->load->view('Admin/login');
		}
		else
		{
				$ad=array(
					'AdminEmailId'=>$this->input->post('Admin_Email'),
					'AdminPassword'=>$this->input->post('Admin_Password')
				);
				$data=$this->mm->do_login($ad,'tbladmin');
				if(count($data)===1)
				{
					$this->session->set_userdata('AdminId',$data[0]->AdminId);
					$this->session->set_userdata('AdminEmailId',$data[0]->AdminEmailId);
					$this->session->set_userdata('AdminName',$data[0]->AdminName);
					
					//new update 4/17/2019 rajesh sir need level table
					$this->session->set_userdata('AdminLevelId',$data[0]->LevelId);
					$where['LevelId']=$data[0]->LevelId;
					$levelData=$this->mm->get_a_data('tbllevel',$where);
					//check_p($levelData[0]->LevelName);
					$this->session->set_userdata('AdminLevelName',$levelData[0]->LevelName);
					redirect('Admin/Dashboard');
				}
				else
				{
					$data['error']="Invalid Email Or password";
					$this->load->view('Admin/login',$data);
				}
			
		
		}
	}
 	public function  comman_header($tblName) //comman header comman_header here
 	{
 	// $data['page']=$this->router->fetch_method();
 	 //  check_p($data);
 	 //before  update of data from data table
 	 
 	 //  $data['Fields']=remove_first_field($this->mm->get_table_heading($tblName));
 	  // after 
 	   $data['Fields']=$this->mm->get_table_heading($tblName);
 	  $data['Fields']=
 	  ($data['Fields']);
 	   $data['OriginalFields']=$data['Fields'];
 	   $data['Fields']=replace_id_name($data['Fields']);
 	    	$data['tableNameData']=$this->mm->get_all_table_heading();
 	    
 	 	$data['sidebarData']=array_map('ucfirst',str_replace('tbl','',$data['tableNameData']));
 	    $data['aocolumns']=get_aocolumns_data($data['Fields']);
 	  //  check_p($data['Fields']);
 	    return $data;
 	}
 	public function  new_comman_header($tblName) //new comman header new_comman_header here
 	{
 	    $data['page']=str_replace('tbl','',$tblName);
 	    // check_p($data);
 	    //before  update of data from data table
 	 
 	    //  $data['Fields']=remove_first_field($this->mm->get_table_heading($tblName));
 	    // after 
 	    $data['Fields']=$this->mm->get_table_heading($tblName);
 	    $data['OriginalFields']=$data['Fields'];
 	    
 	    /*if($data['page']=="member")
 	    {
 	        $data['Fields1']=replace_id_name($this->mm->get_table_heading('tblaccounts'));
 	        $data['OriginalFields1']=$data['Fields1'];
 	        
 	        $data['Fields2']=replace_id_name($this->mm->get_table_heading('tblaccounts'));
 	        $data['OriginalFields2']=$data['Fields2'];
 	    }*/
         	   
     // check_p($tblName);
 	   
 	  //for detail page
 	  if(check_exact_field($tblName,'detail'))
 	  {
 	      $key=remove('detail',$tblName);
 	      $data['DetailFields']=$this->mm->get_table_heading($key);
 	      $data['DetailFields']=remove_last_field($data['DetailFields'],2);
 	      $data['Fields']=array_merge($data['Fields'],$data['DetailFields']);
 	      //check_p($data);
 	  }
 	   
 	   
 	   // check_p($tblName);
 	   
 	  //update for multiple column search 
 	  //$data['Fields']=add_fields($data['Fields']);
 	   $data['Fields']=replace_id_name($data['Fields']);
 	    //check_p($data);
 	   
 	   //updated code rajesh sir 4/18/2019
 	   
    	$sideBarData=$this->get_sidebarData($this->session->AdminLevelId,$data['page'],$data['Fields']);
    	//check_p($sideBarData);
    	$data['adminLevel']=$this->session->AdminLevelId;
 	 	$data['sidebarData']=array_map('ucfirst',str_replace('tbl','',$sideBarData['tableNameData']));
 	 	$data['Fields']=$sideBarData['Fields'];
 	 	$data['adminRights']=$sideBarData['adminRights'];
 	 	$data['aocolumns']=$sideBarData['aocolumns'];
 	   // $data['sidebarData']=array_map('ucfirst',str_replace('tbl','',$this->get_sidebarData($this->session->AdminLevelId,$data['page'])));
 	    $data['ajaxSucessData']=ajax_success_data($data['OriginalFields']);
 	    $data['ajaxSucessJoinDataTest']=(convert_object_arraY($this->mm->get_all_data_join($tblName)));
 	    
 	   // check_p($data['page']);
 	    if($data['page']=="member")
 	        $printKey="member";
 	    else if($data['page']=="memberdetail")
 	        $printKey="memberdetail";
 	    else if($data['page']=="banktransaction")
 	        $printKey="banktransaction";
 	    else if($data['page']=="jobcard")
 	        $printKey="jobcard";
 	    else
 	        $printKey="bill";
 	  
 	    //check_p($data['ajaxSucessJoinDataTest']);
	    
	    if($data['ajaxSucessJoinDataTest'])
	        
	        $data['ajaxSucessJoinData']=ajax_success_data_with_key_innerHTML($data['ajaxSucessJoinDataTest'][0],ucfirst($printKey));
	    else
	        $data['ajaxSucessJoinData']='';
	    //check_p($data);
	 //   check_p($tblName);
 	 
	    return $data;
 	}
 	public function get_sidebarData($SessionId,$pageName,$fields='',$different='')
 	{
 	    //check_p($SessionId);
 	    if($SessionId)
    	{
    	    //new updated code 4/17/2019 rajesh sir
    	   $where['tblrights.LevelId']=$SessionId;
    	   //check_p($where);
    	   $column="RightsTabledropdown";
    	   //   $data['tableNameData']=$this->mm->get_all_table_heading();
    	   $data['Fields']=$fields;
    	   $data['tableNameData']=remove_multi_array_append_data_convert_lower(convert_object_arraY($this->mm->get_a_data_join_a_column('tblrights',$where,$column)),'tbl');
           $selectColumn='*';
           $whereAoColumn['tblrights.LevelId']=$SessionId;
           if(!$different)
                $whereAoColumn['tblrights.RightsTabledropdown']=ucfirst($pageName);
            
            if($fields)
            {
                $data['adminRights']=(convert_object_arraY($this->mm->get_a_data_join_a_column('tblrights',$whereAoColumn,$selectColumn)));
        	    if(! $data['adminRights'][0]['RightsUpdateYesNoRadio'])
                {
                    $data['Fields']=add_a_fields($data['Fields'],"Update");
                }
                if(! $data['adminRights'][0]['RightsDeleteYesNoRadio'])
                {
                    $data['Fields']=add_a_fields($data['Fields'],"Delete");
                }
                 $data['aocolumns']=get_aocolumns_data($data['Fields']);
            }
            /*check_p($data);*/
    	  
    	}
    	else
    	{
    	    $data['tableNameData']=$this->mm->get_all_table_heading();
    	    $data['aocolumns']=get_aocolumns_data($data['Fields']);
 	    
    	}
    	//check_p($data);
    	return $data;
 	}
    public function  new_comman_header_different($data,$tblName='') //new comman header new_comman_header here
 	{
 	    //check_p($data);
        //$data=array();
 	    //$data['Fields']=add_fields($data['Fields']);
 	 
 	    $data['tableNameData']=$this->mm->get_all_table_heading();
 	    if($tblName)
 	         $data['Fields']=$this->mm->get_table_heading($tblName);
 	    else
 	        $data['Fields']=array();
 	    $sideBarData=$this->get_sidebarData($this->session->AdminLevelId,$data['page'],'','yes');
    	//check_p($sideBarData);
    	
 	 	$data['sidebarData']=array_map('ucfirst',str_replace('tbl','',$sideBarData['tableNameData']));
 	 	$data['Fields']=($sideBarData['Fields'])?$sideBarData['Fields']:'';
 	 	$data['adminRights']=(isset($sideBarData['adminRights']))?$sideBarData['adminRights']:'';
 	 	$data['aocolumns']=(isset($sideBarData['aocolumns']))?$sideBarData['aocolumns']:'';
 	 	//$data['sidebarData']=array_map('ucfirst',str_replace('tbl','',$data['tableNameData']));
 	    //$data['aocolumns']=get_aocolumns_data($data['Fields']);
	   //$data['ajaxSucessData']=ajax_success_data($data['OriginalFields']);
	    if($tblName)
	    {
	        $data['ajaxSucessJoinData']=ajax_success_join_data(convert_object_arraY($this->mm->get_all_data_join($tblName)),"Bill");
	    }
 	    //check_p($data);
	    return $data;
 	}
 	public function  AllMethod($tblName = '') //all method in one 
 	{
 	    if(!$this->session->AdminId)
		{
			$this->load->view('Admin/login');
		}
		else
		{
     	  
     	    $data=$this->new_comman_header('tbl'.strtolower($tblName));
     	  
    	    $this->new_comman_view($data);
    	}
 	}
 	public function  index_header() //comman header comman_header here
 	{
    	$data['page']='Dashboard';
    	//check_p($this->session->AdminLevelId);
    	if($this->session->AdminLevelId)
    	{
    	    //new updated code 4/17/2019 rajesh sir
    	   $where['tblrights.LevelId']=$this->session->AdminLevelId;
    	   //check_p($where);
    	   $column="RightsTabledropdown";
    	   $data['tableNameData']=remove_multi_array_append_data_convert_lower(convert_object_arraY($this->mm->get_a_data_join_a_column('tblrights',$where,$column)),'tbl');
    	   //check_p($data['tableNameData']);
    	   //$data['countData']=$this->mm->get_total_no_of_data($data['tableNameData']);
 	 	   
    	   
    	}
    	else
    	{
    	    $data['tableNameData']=$this->mm->get_all_table_heading();
    	}
    	$data['no_of_customers']=$this->mm->get_total_no_of_data('tblcustomer');
 	 	$data['sidebarData']=array_map('ucfirst',str_replace('tbl','',$data['tableNameData']));
 	    return $data;
 	}
 	public function  index_view($data)
 	{
 	    $data['pageName']="Dashboard";
 	      $this->load->view('Admin/header',$data);
	  	$this->load->view('Admin/Sidebar',$data);
 	    $this->load->view('Admin/index1',$data);
 	    $this->load->view('Admin/footer',$data);
	    $this->load->view('Admin/footer_view',$data);
	 
 	}
 	public function  comman_view($data) //comman view comman_view here
 	{   
 	   $data['tblName']="\"tbl".strtolower($data['page'])."\"";
 	  // check_p($data);
 	    $this->load->view('Admin/header',$data);
	  	$this->load->view('Admin/Sidebar',$data);
	  	//$this->load->view('Admin/Modal',$data);
	  	$this->load->view('Admin/'.$data['page'],$data);
 	    $this->load->view('Admin/footer',$data);    
	    $this->load->view('Admin/footer_view',$data);
	    $this->load->view('Admin/AjaxFooter',$data);
	    $this->load->view('Admin/AjaxFooterFormData',$data);
	    $this->load->view('Admin/dataTableFooter',$data);
 	}
    	public function  new_comman_view($data) //comman view comman_view here
 	{   
 	   $data['tblName']="\"tbl".strtolower($data['page'])."\"";
 	  // check_p($data);
 	    $this->load->view('Admin/header',$data);
	  	$this->load->view('Admin/Sidebar',$data);
//	  	$this->load->view('Admin/ExcelDiv',$data);
	  	//$this->load->view('Admin/Modal',$data);
	  	$this->load->view('Admin/Main',$data);
 	    $this->load->view('Admin/footer',$data);    
	    $this->load->view('Admin/AjaxFooter',$data);
	    $this->load->view('Admin/AjaxFooterFormData',$data);
	    $this->load->view('Admin/AjaxCSV',$data);
	    $this->load->view('Admin/CustomJs',$data);
	    $this->load->view('Admin/dataTableFooter',$data);
	    $this->load->view('Admin/DetailView',$data);
	
	 //   $this->load->view('Admin/footer_view',$data);
	   
 	}
 	public function  new_comman_view_different($data) //comman view comman_view here
 	{   
 	 //  $data['tblName']="\"tbl".strtolower($data['page'])."\"";
 	  // check_p($data);
 	    $this->load->view('Admin/header',$data);
	  	$this->load->view('Admin/Sidebar',$data);
        //$this->load->view('Admin/ExcelDiv',$data);
	  	//$this->load->view('Admin/Modal',$data);
	  	$this->load->view($data['pageLink'],$data);
 	    $this->load->view('Admin/footer',$data);    
	    $this->load->view('Admin/AjaxFooterDifferent',$data);
	    //$this->load->view('Admin/AjaxFooterFormData',$data);
	    //$this->load->view('Admin/AjaxCSV',$data);
	    //$this->load->view('Admin/CustomJs',$data);
	    //$this->load->view('Admin/dataTableFooter',$data);
	    $this->load->view('Admin/footer_view',$data);
	   
 	}

}
