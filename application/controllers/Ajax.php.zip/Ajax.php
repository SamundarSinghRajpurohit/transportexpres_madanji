<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$set['upload_path']='./resources/images/';
		$set['allowed_types']='png|jpg|gif|jpeg|csv';
		$this->load->library('upload',$set);
		date_default_timezone_set('Asia/Kolkata');
		$this->load->helper('url');
	//	$this->load->model('Admin/dashboard_m','dm');
		$this->load->helper('custom_helper');
		$this->load->library('csvimport');
		$this->load->library('session');
       	$this->load->model('Admin/MainModel','mm');
	 $this->load->library('excel');
	}
	public function print_a_bill($tblName,$id) // for printing a bill
	{
	        $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	        $data=array($tableIdName=>$id);
	        
	        $arrayData=array();
	        $tableDetailName=$tblName.'detail';
            $tablePresent=$this->mm->check_table_present($tableDetailName);
            
            if ($tablePresent)
            {
                $detailTableIdName=ucfirst(remove("tbl",$tblName)."Id".DETAIL_COLUMN_REFERNCE);
	            $detailData=array($tableDetailName.'.'.$detailTableIdName=>$id);
              //  $detailData=$this->mm->get_a_data_join($tableDetailName,$detailData);
                $detailData=convert_object_array($this->mm->get_main_data_join($tableDetailName,$detailData));
                $i=0;
                $str='';
                $strFinal='';
                //$tagName="<td>";
                
                $tblkey=ucfirst(remove("tbl",$tblName).DETAIL_TABLE);
                foreach($detailData as $data)
                {   $i++;
                    //removing first n last 2 elemnts
                    $data=array_slice($data, 1, -2, true);
                    $strStart="<tr id='tableRow$i'>";
                    $str='';
                    foreach($data as $key=>$value)
                    {
                            //echo $key."<br>";
                            $str=$str.get_input_field($key,$tblkey,'3','td',"update".$i,$value);
                            //echo $str;                            
                        
                    }
                    $strEnd="</tr>";
                
                    $strFinal=$strFinal.$strStart.$str.$strEnd;
                        //echo "<pre>";
                      //  echo "asd";
                  //  echo($strFinal);
                    
                }
               // check_p($strFinal);
                //print_r($strFinal);
                $arrayData['AppendString']=$strFinal;
                //$data[]=$strFinal;
                //check_p($strFinal);
            }
	        $jsonData=$this->mm->get_a_data_join($tblName,$data);
             echo json_encode($jsonData);
	}
	
	public function PreInvoiceDifferent($tblName,$id='',$tagName='') // for Print Pre Invoice
	{       
	        $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	        $data=array($tableIdName=>$id);
	        
	        $arrayData=array();
	        $tableDetailName=$tblName.'detail';
            $tableDetailName2=$tblName.'detail2';
            
            $detailTableIdName=ucfirst(remove("tbl",$tblName)."Id".DETAIL_COLUMN_REFERNCE);
            $detailTableIdName2=ucfirst(remove("tbl",$tblName)."Id".DETAIL_COLUMN_REFERNCE);
            //check_p($detailTableIdName2);
            $mainData=array($tblName.'.'.$tableIdName=>$id);
            
            //check_p($mainData);
            
            $detailData=array($tableDetailName.'.'.$detailTableIdName=>$id);
            $detailData2=array($tableDetailName2.'.'.$detailTableIdName2=>$id);
            //check_p($detailData2);
            
            //$detailData=convert_object_array($this->mm->get_main_data_join($tableDetailName,$detailData));
            $data['detailProduct']=convert_object_array($this->mm->get_a_data_join($tableDetailName,$detailData));
            $data['detailJobWork']=convert_object_array($this->mm->get_a_data_join($tableDetailName2,$detailData2));
            $data['hsn']=convert_object_array($this->mm->get_all_data('tblhsn'));
            $mainDataFilled=convert_object_array($this->mm->get_a_data_join($tblName,$mainData));
            
            
            $customerId=$mainDataFilled[0]['CustomerId'];
            $customerData=array('tblcustomer'.'.'.'CustomerId'=>$customerId);
            $customerDataFilled=convert_object_array($this->mm->get_a_data_join('tblcustomer',$customerData));
            $data['vehicleModelName']=$customerDataFilled[0]['VechileModelName'];
            
            $advisoryId=$mainDataFilled[0]['AdvisoryId'];
            //check_p($customerDataFilled);
            $advisoryData=array('tbladvisory'.'.'.'AdvisoryId'=>$advisoryId);
            $advisoryDataFilled=convert_object_array($this->mm->get_a_data('tbladvisory',$advisoryData));
              
            /*$VechilemodelId=$mainDataFilled[0]['VechilemodelId'];
           // check_p($advisoryId);
            $VechilemodelData=array('tblVechilemodel'.'.'.'VechilemodelId'=>$VechilemodelId);
            $VechilemodelFilled=convert_object_array($this->mm->get_a_data('tblVechilemodel',$VechilemodelData));
            *///all data in one array
            $data['mainData']=array_merge($mainDataFilled[0],$customerDataFilled[0],$advisoryDataFilled[0]);
            $data['tableHeading']=array('Srl.','Part Name/Desc','HSN/SAC','TAX','QTY','Rate','Taxable Amount','Tax Paid Amount','Labour Charges');
            $data['bankDetail']=array('AcName'=>'Devi Motors','AcNumber'=>'38914837484','IFSCCode'=>'SBIN0002636','BankName'=>'SBI');
            //check_p($data);
            $this->load->view('Admin/PreInvoiceFull',$data);
	        
	}
	public function BillDifferent($tblName,$id='',$tagName='') // for Print Pre Invoice
	{   	        
	        $mainTblName=$tblName;
	        $mainId=$id;
	        $mainTableIdName=ucfirst(remove("tbl",$mainTblName)."Id");
	        $mainDataFinal=array($mainTableIdName=>$mainId);
	        $mainDataFinal=convert_object_array($this->mm->get_a_data_join($mainTblName,$mainDataFinal));
            
            //check_p($mainDataFinal);
	        
	        
	        $tblName='tblpreinvoice'; 
	        $jobCardId=$mainDataFinal[0]['JobCardId'];
	        $tableIdName='JobCardId';
	        $data=array($tableIdName=>$jobCardId);
	        $mainData=array($tblName.'.'.$tableIdName=>$jobCardId);
	        //print_r($mainDataFinal);
	        $mainJobCardData=convert_object_array($this->mm->get_a_data_join($tblName,$mainData));
	        
	        $data['InvoiceId']=$mainDataFinal[0]['BillId'];
            //check_p($mainJobCardData[0]['PreInvoiceId']);
	        $id=$mainJobCardData[0]['PreInvoiceId'];
	        
	        $arrayData=array();
	        //$id=ucfirst(remove("tbl",$tblName)."Id");
	        $tableDetailName=$tblName.'detail';
            $tableDetailName2=$tblName.'detail2';
            
            $detailTableIdName=ucfirst(remove("tbl",$tblName)."Id".DETAIL_COLUMN_REFERNCE);
            $detailTableIdName2=ucfirst(remove("tbl",$tblName)."Id".DETAIL_COLUMN_REFERNCE);
            //check_p($detailTableIdName2);
            
            //check_p($mainData);
            
            $detailData=array($tableDetailName.'.'.$detailTableIdName=>$id);
            $detailData2=array($tableDetailName2.'.'.$detailTableIdName2=>$id);
            //check_p($detailData);
            
            //$detailData=convert_object_array($this->mm->get_main_data_join($tableDetailName,$detailData));
            $data['detailProduct']=convert_object_array($this->mm->get_a_data_join($tableDetailName,$detailData));
            $data['detailJobWork']=convert_object_array($this->mm->get_a_data_join($tableDetailName2,$detailData2));
            $data['hsn']=convert_object_array($this->mm->get_all_data('tblhsn'));
            $mainDataFilled=convert_object_array($this->mm->get_a_data_join($tblName,$mainData));
            //check_p($mainDataFilled);
            if(!empty($mainDataFilled))
            {
            $customerId=$mainDataFilled[0]['CustomerId'];
            $customerData=array('tblcustomer'.'.'.'CustomerId'=>$customerId);
            $customerDataFilled=convert_object_array($this->mm->get_a_data_join('tblcustomer',$customerData));
            $data['vehicleModelName']=$customerDataFilled[0]['VechileModelName'];
            
            $advisoryId=$mainDataFilled[0]['AdvisoryId'];
            //check_p($customerDataFilled);
            $advisoryData=array('tbladvisory'.'.'.'AdvisoryId'=>$advisoryId);
            $advisoryDataFilled=convert_object_array($this->mm->get_a_data('tbladvisory',$advisoryData));
              
            /*$VechilemodelId=$mainDataFilled[0]['VechilemodelId'];
           // check_p($advisoryId);
            $VechilemodelData=array('tblVechilemodel'.'.'.'VechilemodelId'=>$VechilemodelId);
            $VechilemodelFilled=convert_object_array($this->mm->get_a_data('tblVechilemodel',$VechilemodelData));
            *///all data in one array
            $data['mainData']=array_merge($mainDataFilled[0],$customerDataFilled[0],$advisoryDataFilled[0]);
            $data['tableHeading']=array('Srl.','Part Name/Desc','HSN/SAC','TAX','QTY','Rate','Taxable Amount','Tax Paid Amount','Labour Charges');
            $data['bankDetail']=array('AcName'=>'Devi Motors','AcNumber'=>'38914837484','IFSCCode'=>'SBIN0002636','BankName'=>'SBI');
            //check_p($data);
                $this->load->view('Admin/InvoiceFull',$data);
                
            }
            else
            {    $data['error']="No preinvoice found of this jobcard";
                $this->load->view('Admin/InvoiceError',$data);
            }
	        
	}
	public function InvoiceDifferent($tblName,$id='',$tagName='') // for Print Pre Invoice
	{       
	        $mainTblName=$tblName;
	        $mainId=$id;
	        $mainTableIdName=ucfirst(remove("tbl",$mainTblName)."Id");
	        $mainDataFinal=array($mainTableIdName=>$mainId);
	        $mainDataFinal=convert_object_array($this->mm->get_a_data_join($mainTblName,$mainDataFinal));
            
          
	        $tblName='tblpreinvoice'; 
	        $id=$mainDataFinal[0]['PreInvoiceId'];
	        $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	        $data=array($tableIdName=>$id);
	        
	        $arrayData=array();
	        $tableDetailName=$tblName.'detail';
            $tableDetailName2=$tblName.'detail2';
            
            $detailTableIdName=ucfirst(remove("tbl",$tblName)."Id".DETAIL_COLUMN_REFERNCE);
            $detailTableIdName2=ucfirst(remove("tbl",$tblName)."Id".DETAIL_COLUMN_REFERNCE);
            //check_p($detailTableIdName2);
            $mainData=array($tblName.'.'.$tableIdName=>$id);
            //check_p($mainData);
            
            $detailData=array($tableDetailName.'.'.$detailTableIdName=>$id);
            $detailData2=array($tableDetailName2.'.'.$detailTableIdName2=>$id);
            //check_p($detailData2);
            
            //$detailData=convert_object_array($this->mm->get_main_data_join($tableDetailName,$detailData));
            $data['detailProduct']=convert_object_array($this->mm->get_a_data_join($tableDetailName,$detailData));
            $data['detailJobWork']=convert_object_array($this->mm->get_a_data_join($tableDetailName2,$detailData2));
            $data['hsn']=convert_object_array($this->mm->get_all_data('tblhsn'));
            $mainDataFilled=convert_object_array($this->mm->get_a_data_join($tblName,$mainData));
            
            
            $customerId=$mainDataFilled[0]['CustomerId'];
            $customerData=array('tblcustomer'.'.'.'CustomerId'=>$customerId);
            $customerDataFilled=convert_object_array($this->mm->get_a_data_join('tblcustomer',$customerData));
            
             $customerDataFilled=convert_object_array($this->mm->get_a_data_join('tblcustomer',$customerData));
            $data['vehicleModelName']=$customerDataFilled[0]['VechileModelName'];
            $advisoryId=$mainDataFilled[0]['AdvisoryId'];
           // check_p($advisoryId);
            $advisoryData=array('tbladvisory'.'.'.'AdvisoryId'=>$advisoryId);
            $advisoryDataFilled=convert_object_array($this->mm->get_a_data('tbladvisory',$advisoryData));
            
            //all data in one array
            $data['mainData']=array_merge($mainDataFilled[0],$customerDataFilled[0],$advisoryDataFilled[0]);
            $data['tableHeading']=array('Srl.','Part Name/Desc','HSN/SAC','TAX','QTY','Rate','Taxable Amount','Tax Paid Amount','Labour Charges');
            $data['bankDetail']=array('AcName'=>'Devi Motors','AcNumber'=>'38914837484','IFSCCode'=>'SBIN0002636','BankName'=>'SBI');
            //check_p($data);
            $this->load->view('Admin/InvoiceFull',$data);
	        
	}
	public function add_heading($tblkey,$footer='',$no='') // for Adding heading and footer
	{       
	        //check_p($tblName.DETAIL_TABLE);
	        //before devi
	        //$tblName="tbl".$tblkey.DETAIL_TABLE;
	        //after
	        if (preg_match('~[0-9]+~', $tblkey)) 
	        {    $tblName=$tblkey;
            }else
	           $tblName=$tblkey.DETAIL_TABLE;
	        //check_p($tblName);
	        $tblkey=ucfirst($tblkey.DETAIL_TABLE);
	        $detailData=$this->mm->get_table_heading($tblName);
            
            //print_r($detailData);
            $detailData=remove_last_field($detailData,2);
            $detailData=remove_first_field($detailData);
            //array_push($detailData,'Remove');
            $detailData=replace_id_name($detailData);
            
            //for detail  Id refernce patiya method
            $detailData=remove_first_field($detailData);
            //$detailData=add_remove_clear_option($detailData);
            $inputStr="";
            //check_p($tblkey);
            if($footer)
            {
                $tagStart1="<td";
                $tagStart3=">";
                $tagEnd="</td>";
                $n=0;
                foreach($detailData as $detailDataValue)
                {
                    $n++;
                    $inputStr=$inputStr.'<td id=total'.$n.'><b>'.remove($tblkey,$detailDataValue).'</b>'.$tagEnd;
                }
            }
            else
            {
                $tagStart1="<th";
                $tagStart3=">";
                $tagEnd="</th>";
                foreach($detailData as $detailDataValue)
                {
                    $inputStr=$inputStr.$tagStart1.$tagStart3.remove($tblkey,$detailDataValue).$tagEnd;
                }
                
            }
                $inputStr="<tr>".$inputStr."</tr>";
            //$str="$('#DetailView').append($inputStr)"; 
           // echo htmlspecialchars($str);
           
            echo ($inputStr);
	}
	public function add_columns($tblkey,$uniqueKey='',$disableField='') // for Adding columns a bill
	{       
	        //check_p($tblName.DETAIL_TABLE);
	        if(!check_substr($tblkey,"detail")){
	            $tblName="tbl".$tblkey.DETAIL_TABLE;
	            $tblkey=ucfirst($tblkey.DETAIL_TABLE);
	        }
	        else{ $tblName="tbl".$tblkey;
	        $tblkey=ucfirst($tblkey);
	        }
	      //  check_p($tblName);
	               
	        $detailData=$this->mm->get_table_heading($tblName);
            $detailData=remove_last_field($detailData,2);
            $detailData=remove_first_field($detailData);
            $detailData=add_remove_clear_option($detailData);
            $inputStr="";
           // check_p($detailData);
            foreach($detailData as $detailDataValue)
            {
                $inputStr=$inputStr. get_input_field($detailDataValue,$tblkey,'3','td',$uniqueKey,'',$disableField);
        
            }
                  $inputStr="<tr id='".TABLE_ROW."$uniqueKey'>".$inputStr."</tr>";
            //$str="$('#DetailView').append($inputStr)"; 
           // echo htmlspecialchars($str);
            echo ($inputStr);
	}
	public function import_CSV($KeyName)
	{
	        $tblName="tbl".strtolower($KeyName);
	        $tableField=$this->mm->get_table_heading($tblName);
	        $tableField=remove_first_last_field($tableField);
	         $selectedCol='';
	        $data=array();
	        //check_p($tableField);
	                   //check_p($data['check_data']);
	    	$data['error'] = '';    //initialize image upload error array to empty
		    if (!$this->upload->do_upload("ImportCSV")) 
			{
			    $data['error'] = $this->upload->display_errors();
                echo json_encode($data);
			} 
			else
			{
			    foreach($tableField as $tableFieldData)
			    {
                        //if(check_substr($tableFieldData,"Id"))
                    if(stripos($tableFieldData,DETAIL_COLUMN_REFERNCE)!==false)
                    {
                              $data['check_data'][]=remove("Id".DETAIL_COLUMN_REFERNCE,$tableFieldData)."Name";
                    }
                    else if((strpos($tableFieldData,'Id')!==false)&&!(stripos($tableFieldData,'Email')!==false))
                    {
                            //$data['Join_table'][]="tbl".strtolower(remove("Id",$tableFieldData));
                              $data['check_data'][]=remove("Id",$tableFieldData)."Name";
                    }
			    }
			  
			    $file_data = $this->upload->data();
			    $file_path =  './resources/images/'.$file_data['file_name'];
			    
			    if ($this->csvimport->get_array($file_path)) 
			    {
			        $csv_array = $this->csvimport->get_array($file_path);
		          //echo "hello";
		          //check_p($csv_array);
		           //check_p($csv_array);
		            $filterCSV=array();
		            $i=0;
		            $dataId=array();
		            foreach($csv_array as $arrayData)
			           {
			               
			               $filterCSV[$i]=array();
                            
    			           foreach($arrayData as $key=>$value)
    			           {
    			               /*foreach($tableField as $tableFieldKey=>$tableFieldData)
    			               if(check_substr($key,$tableFieldKey))
    			               {
    			                   // $filterCSV[$i][$key]=;
    			               }*/  
                                    if(isset($data['check_data'])&&in_array($key,$data['check_data']))
                                    {
                                        //echo $arrayData[$key];
                                        //echo $key."=".$arrayData[$key];
                                        //$innerTblName="";
                                        //$selectedCol="";
                                        //$whereCol="";
                                        //$whereData=null;
                                        $innerTblName="tbl".strtolower(remove("Name",$key));
                                        $selectedCol=remove("Name",$key)."Id";
                                        $whereCol=$key;
                                        $whereData=$arrayData[$key];
                                        $dataId=$this->mm->get_id($innerTblName,$selectedCol,$whereCol,$whereData);
                                        
                                        
                                        if(empty($dataId))
                                        { 
                                          $insertData[$whereCol]=$whereData;
                                          //custom code for dholi sati start 
                                          if((strcmp($innerTblName,"tblcustomer")==0))
                                          {     $insertData['CustomerUserName']=substr(preg_replace('/\s+/', '', $whereData),0,6);
                                                $insertData['CustomerPassword']=rand_string(6);
                                          }
                                          //custom code for dholi sati ends
                                          $dataId=$this->mm->insert_get_id($innerTblName,$insertData);
                                          $dataId=$this->mm->get_id($innerTblName,$selectedCol,$whereCol,$whereData);
                                          $innerTblName='';
                                          $insertData=array();
                                        //  $insertData=null;
                                        }
                                        $dataId=convert_object_array($dataId);
                                            foreach($dataId as $dataIdKey=>$dataIdData)
                                            {
                                                if(is_array($dataIdData)) 
                                                {   foreach($dataIdData as $dataIdKeyDetail=>$dataIdDataDetail)
                                                    {      
                                                       if(isset($dataIdKeyDetail))
                                                       {
                                                              $filterCSV[$i][$dataIdKeyDetail]=$dataIdDataDetail;
                                                       }
                                                    }
                                                }
                                            }
                                        
                                    }
                                    else
                                    {   $filterCSV[$i][$key]=$value;
                                    }
                                  
    			           }
    			          $mainData=array();
    			          $j=0;
    			          foreach($filterCSV[$i] as $filterCSVKey=>$filterCSVvalue)
    			          {
    			              $mainData[$tableField[$j++]]=$filterCSVvalue;
    			          }
    			          //echo "<pre>";
    			          //print_r($mainData);
    			           $this->mm->insert_a_data($tblName,$mainData);
                             $i++;
    			         
                           //end of main foreach
			           }
                                    		        
			    }
			  
			}
			
	   echo 1;
	   //end of import_CSV
	}
	public function get_all_data()
	{ //  echo "asd";
	   $tblName=$this->input->get('tblName');
	   //check_p($tblName);
	   $data['datasource']=$this->mm->get_all_data_join($tblName);
	 //  $this->load->view('Bill',$data);
	    echo json_encode($data);
	}
	public function get_a_data($tblName,$id,$tagName='',$key='',$uniqueId='')
	{
	       
	        
            $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	        $whereData=array($tblName.".".$tableIdName=>$id);
	        $arrayData=array();
	      /*  $allTableDetail=$this->mm->get_custom_join_data($tblName,1);
	        check_p($allTableDetail);
	       */
	        //check_p($tblName);
	        $tableDetailName=$tblName.'detail';
            $tablePresent=$this->mm->check_table_present($tableDetailName);
              //check_p($tableDetailName);
           
            if ($tablePresent)
            {
                $detailTableIdName=ucfirst(remove("tbl",$tblName)."Id".DETAIL_COLUMN_REFERNCE);
	            $detailData=array($tableDetailName.'.'.$detailTableIdName=>$id);
              //  $detailData=$this->mm->get_a_data_join($tableDetailName,$detailData);
                $detailData=convert_object_array($this->mm->get_main_data_join($tableDetailName,$detailData));
                $i=0;
                $str='';
                $strFinal='';
                if(strcmp($tagName,"notag")==0)
                    $tagName="label";
                $tblkey=ucfirst(remove("tbl",$tblName).DETAIL_TABLE);
                //check_p($detailData);
                foreach($detailData as $data)
                {   $i++;
                    //removing first n last 2 elemnts
                    $data=array_slice($data, 1, -2, true);
                    $strStart="<tr id='tableRow$i'>";
                    $str='';
                    $label='';
                    foreach($data as $key=>$value)
                    {
                            //echo $key."<br>";
                            $str=$str.get_input_field($key,$tblkey,'3',$tagName,"update".$i,$value);
                           // echo $str;                            
                        
                    }
                    $strEnd="</tr>";
                
                    $strFinal=$strFinal.$strStart.$str.$strEnd;
                        //echo "<pre>";
                      //  echo "asd";
                  //  echo($strFinal);
                    
                }
                //check_p($strFinal);
                //print_r($strFinal);
                $arrayData['AppendString']=$strFinal;
                
                //$data[]=$strFinal;
                //check_p($strFinal);
            }
            //$jsonData[0]=$this->mm->get_a_data_join($tblName,$whereData);
	        $jsonData=$this->mm->get_a_data_join($tblName,$whereData);
            //for datalist 
            
            $jsonData[0]=get_array_for_datalist(convert_object_array($jsonData[0]),$tableIdName);
            //$jsonData=$this->mm->get_a_data_join_datalist($tblName,$whereData);
             if($tagName=="notag")
                   $AjaxSucessData=ajax_success_data_with_key_innerHTML($jsonData[0],$key,$uniqueId);
             else if($tagName=="label")
                $AjaxSucessData=ajax_success_data_with_key_innerHTML($jsonData[0],$key,$uniqueId);
             else
                 $AjaxSucessData=ajax_success_data_with_key($jsonData[0],$key,$uniqueId);               
             //$AjaxSucessDataDemo="$('#PurchaseOrderno').val('asd');";
             $data['AjaxSucessData']=$AjaxSucessData;
              //check_p($AjaxSucessData);
        
                array_push($jsonData,$arrayData);
                array_push($jsonData,$AjaxSucessData);
            //check_p($jsonData);
         echo $data=json_encode($jsonData);
		    
	}
	public function get_accounts_data($tblName)
	{
	        $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	        $whereData=array($tblName.'.'.$tableIdName=>$this->input->post($tableIdName));
	        $cashData;
	         //check_p();
            //if($this->input->post("LedgerAccountsDataRadio")=="")
            $fromDate=$this->input->post("LedgerFromDate");
            $toDate=$this->input->post("LedgerToDate");
            if($this->input->post("LedgerAccountsDataRadio")=="Master")
            {
                $bankData=$this->mm->get_a_data_join("tblbanktransaction",$whereData,$fromDate,$toDate);
                $cashData=$this->mm->get_a_data_join("tblcashtransaction",$whereData,$fromDate,$toDate);
                $cashRetailData=$this->mm->get_a_data_join("tblcashretailtransaction",$whereData,$fromDate,$toDate);
                $salesData=$this->mm->get_a_data_join("tblsales",$whereData,$fromDate,$toDate);
                $purchaseData=$this->mm->get_a_data_join("tblpurchase",$whereData,$fromDate,$toDate);
                //check_p($cashRetailData);
            }
            else if($this->input->post("LedgerAccountsDataRadio")=="All")
            {
                $bankData=$this->mm->get_a_data_join("tblbanktransaction",$whereData,$fromDate,$toDate);
                $cashData=$this->mm->get_a_data_join("tblcashtransaction",$whereData,$fromDate,$toDate);
                $salesData=$this->mm->get_a_data_join("tblsales",$whereData,$fromDate,$toDate);
                $purchaseData=$this->mm->get_a_data_join("tblpurchase",$whereData,$fromDate,$toDate);
                
            }
            elseif($this->input->post("LedgerAccountsDataRadio")=="Cashretail")
            {
                $cashRetailData=$this->mm->get_a_data_join("tblcashretailtransaction",$whereData,$fromDate,$toDate);
            }
	        
            
            $data='';
    	    if(!empty($bankData))
    	    {   $bankData=convert_object_array($bankData);
	            $data=$data.convet_array_ledger($bankData,"Banktransaction");
    	    }
    	    if(!empty($cashData))
    	    {   $cashData=convert_object_array($cashData);
    	        $data=$data.convet_array_ledger($cashData,"Cashtransaction");
    	    }
    	    if(!empty($cashRetailData))
    	    {   $cashRetailData=convert_object_array($cashRetailData);
    	        $data=$data.convet_array_ledger($cashRetailData,"Cashretailtransaction");
    	    }
    	    echo ($data);
    }
    public function get_bank_data($tblName)
	{
	        $tblKey=ucfirst(remove("tbl",$tblName));
	        $tableIdName=$tblKey."Id";
	        $whereData=array($tblName.'.'."BankId"=>$this->input->post('BankId'));
	        $cashData;
	         //check_p();
            //if($this->input->post("LedgerAccountsDataRadio")=="")
            $fromDate=$this->input->post("BankLedgerFromDate");
            $toDate=$this->input->post("BankLedgerToDate");
            //check_p($whereData);   
            $bankData=$this->mm->get_a_data_join("tblbanktransaction",$whereData,$fromDate,$toDate);
                //check_p($bankData);
        /*        $cashData=$this->mm->get_a_data_join("tblcashtransaction",$whereData,$fromDate,$toDate);
                $salesData=$this->mm->get_a_data_join("tblsales",$whereData,$fromDate,$toDate);
                $purchaseData=$this->mm->get_a_data_join("tblpurchase",$whereData,$fromDate,$toDate);
            */
            $data='';
    	    if(!empty($bankData))
    	    {   $bankData=convert_object_array($bankData);
	            $data=$data.convet_array_ledger($bankData,"Banktransaction","AC");
    	    }
    	   /* if(!empty($cashData))
    	    {   $cashData=convert_object_array($cashData);
    	        $data=$data.convet_array_ledger($cashData,"Cashtransaction");
    	    }
    	    if(!empty($cashRetailData))
    	    {   $cashRetailData=convert_object_array($cashRetailData);
    	        $data=$data.convet_array_ledger($cashRetailData,"Cashretailtransaction");
    	    }*/
    	    echo ($data);
    }
    public function get_cash_data($tblName)
	{
	        $tblKey=ucfirst(remove("tbl",$tblName));
	        $tableIdName=$tblKey."Id";
	        $whereData=array();
	        $cashData;
	        $fromDate=$this->input->post("CashLedgerFromDate");
            $toDate=$this->input->post("CashLedgerToDate");
            $bankData=$this->mm->get_a_data_join("tblcashtransaction",$whereData,$fromDate,$toDate);
              
            $data='';
    	    if(!empty($bankData))
    	    {   $bankData=convert_object_array($bankData);
	            $data=$data.convet_array_ledger($bankData,"Cashtransaction","AC");
    	    }
    	   
    	    echo ($data);
    }
	public function delete_a_data($tblName,$id)
	{
	      //  check_p($tblName);
            $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	        $data=array($tableIdName=>$id);
	      /*  $allTableDetail=$this->mm->get_custom_join_data($tblName,1);
	        check_p($allTableDetail);
	       */ $jsonData=$this->mm->delete_a_data($tblName,$data);
        
         echo $data=json_encode($jsonData);
		    
	}
	
	public function get_a_data_purchase_custom($tblName,$id)
	{
	         $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	        // $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	        $data=array($tableIdName=>$id);
	        $data1=$this->mm->get_a_data_join($tblName,$data);
            $data1=convert_object_array($data1);
            $data2=$this->mm->get_a_data('tblhsn','HsnId',$data1[0]['HsnId']);
            $data2=convert_object_array($data2);
            $mainData=array_merge($data1[0],$data2[0]);
            
	        $jsonData=$mainData;
        
         echo json_encode($jsonData);
		    
	}
	public function update_status($tblName,$id) //updating status
	{
	    $tableIdName=ucfirst(remove("tbl",$tblName)."Id");
	    $data=array($tableIdName=>$id);
	   $jsonData=$this->mm->update_status($tblName,$data);
         echo json_encode($jsonData);
	 }
	public function get_active_data_name($tblName = '',$fieldName ='')
	{   
	    $tableField=array();
	       $tableField=$this->mm->get_active_data_name($tblName,$fieldName);
	     //   check_p($tableField);  
        return 	$tableField;
	}
	public function get_direct_data($name = '')
	{
	}
	public function get_data($name = '')
	{
	    $tblName="tbl".strtolower($name);
	    $tableField=$this->mm->get_table_heading($tblName);
	    $tableField=remove_first_last_field($tableField);
	    $tableName=array();
        foreach($tableField as  $tableFieldcol)
	    {
	            if(check_exact_field($tableFieldcol,'Id')&&!check_exact_field($tableFieldcol,'Email'))
	            {
	              $tableName[]=array("tbl".strtolower(remove("Id",$tableFieldcol)),remove("Id",$tableFieldcol)."Name");
	            }
	    }
    	foreach($tableName as $tableNameData)
    	{  
    	    $tableWithField[$tableNameData[0]]=$this->get_active_data_name($tableNameData[0],$tableNameData[1]);
	    }
	   // check_p(json_encode($tableWithField));
	    if(!empty($tableWithField))
	   {    
	    echo json_encode($tableWithField);
	   }
	}
	public function CreateExcel($data)
	{  
	    //check_p($data);
	    //load our new PHPExcel library
          //  $this->load->library('excel');
            //activate worksheet number 1
            $this->excel->setActiveSheetIndex(0);
            //name the worksheet
            $this->excel->getActiveSheet()->setTitle('test worksheet');
            //set cell A1 content with some text
            $this->excel->getActiveSheet()->setCellValue('A1', 'This is just some text value');
             
            $filename='just_some_random_name.xls'; //save our workbook as this file name
            header('Content-Type: application/vnd.ms-excel'); //mime type
            header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
            header('Cache-Control: max-age=0'); //no cache
                        
            //save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
            //if you want to save it as .XLSX Excel 2007 format
            $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
            //force user to download the Excel file without writing it to server's HD
            $objWriter->save('php://output');
   	}
   	public function insert_data_function($tableField,$uniqueId='',$lastInsertId='',$tableName='')
	{
	            $dataTableField=array();
	            //check_p($tableField);
	            foreach($tableField as  $tableFieldcol)
	            {
    	            if(check_field($tableFieldcol,'Image')||check_field($tableFieldcol,'Logo'))
    	            {
    	                 if($this->upload->do_upload($tableFieldcol.$uniqueId))
        		         {   
        		        	$udata=$this->upload->data();
        			        $dataTableField[$tableFieldcol]=$udata['file_name'];
        		         }
        		         else
        		         {
        		                if($this->input->post($tableFieldcol."Name"))
        		                {  //check_p($this->input->post($tableFieldcol."Name"));
        		                  
        		                        $dataTableField[$tableFieldcol]=$this->input->post($tableFieldcol."Name".$uniqueId);
        		                }
        		                else
        		                {  // check_p($this->input->post($tableFieldcol."Name"));
        		                    $dataTableField[$tableFieldcol]="no_img.jpg";
        		                }    		                
        		         }
    	            }
    	            else if(check_field($tableFieldcol,DETAIL_COLUMN_REFERNCE))
    	            {
    	                    //$dataTableField[$tableFieldcol]=$lastInsertId;
    	                    if($lastInsertId)
    	                        $dataTableField[$tableFieldcol]=$lastInsertId;
    	                    else
    	                      $dataTableField[$tableFieldcol]=($this->input->post($tableFieldcol.$uniqueId)==NULL)?'':$this->input->post($tableFieldcol.$uniqueId);
    	                
    	            }
    	           /* else if((strpos($tableFieldcol,'Id')!==false)&&!(stripos($tableFieldcol,'Email')!==false))
    	            {
    	               
    	                $dataTableField[$tableFieldcol]=($this->input->post($tableFieldcol.$uniqueId)==NULL)?'':substr($this->input->post($tableFieldcol.$uniqueId), 0, strpos($this->input->post($tableFieldcol.$uniqueId), '-'));
    	                  //echo $tableFieldcol.$dataTableField[$tableFieldcol];
    	                  //$dataId=$this->mm->get_id($tableName,$selectedCol,$whereCol,$whereData);
                       // echo $dataTableField[$tableFieldcol]."id wala";                      
    	                    //$dataTableField[$tableFieldcol]=$lastInsertId;
    	            }*/
    	            else if(check_exact_field($tableFieldcol,'MemberNo')&&!check_exact_field($tableFieldcol,'MemberNoOfMembers'))
    	            {
    	                //$dataTableField[$tableFieldcol]=($this->input->post($tableFieldcol.$uniqueId)==NULL)?'':$this->input->post($tableFieldcol.$uniqueId);
    	                
    	                $data=($this->input->post($tableFieldcol.$uniqueId)==NULL)?'':$this->input->post($tableFieldcol.$uniqueId);
    	                
    	                /*echo "Last";
    	                print_r($tableFieldcol.$data[0]);
    	                */$dataTableField[$tableFieldcol]=preg_replace("/[^0-9]/", '', $data);
    	                
    	            }
    	            else 
    	            {
    	            
    	                 $dataTableField[$tableFieldcol]=($this->input->post($tableFieldcol.$uniqueId)==NULL)?'':$this->input->post($tableFieldcol.$uniqueId);
    	                 //   echo $dataTableField[$tableFieldcol]."normal";  
    	            }
	           
	            }
	            return $dataTableField;
	        }
	public function insert_data($name = '',$detailArray='')  //inserting a data in table
	{      
	      
	        $colName=strtolower($name);
	        $tblName="tbl".$colName; 
	        $tableField=$this->mm->get_table_heading($tblName);
	        $tableField=remove_last_field($tableField,2);
	        // $tableField=remove_first_field($tableField);
	        $dataTableField=array();
	        $lastInsertId;
	        $dataTableField=$this->insert_data_function($tableField);
	        $dataTableField[ucfirst($name."CDT")]=date('Y-m-d H:i:s');
	        $dataTableField[ucfirst($name."Status")]=0;
	       //check_p($this->input->post($tableField[0]));
	       if($this->input->post($tableField[0])!=NULL)
	       { //UPDATE DATA
              //  echo "Update Data";
              //check_p($this->input->post($tableField[0]));
                //check_p($dataTableField);
                $data=$this->mm->update_data($tblName,$dataTableField,$tableField[0],$this->input->post($tableField[0]));
	            $lastInsertId=$this->input->post($tableField[0]);
	            $tableDetailName='tbl'.$name.'detail';
                $tablePresent=$this->mm->check_table_present($tableDetailName);
                if ($tablePresent)
                {
                    //check_p($tableDetailName);
                    $detailArray=explode(',',($_POST['DetailArray']));
	                $tableField=$this->mm->get_table_heading($tableDetailName);
            	    //check_p($detailArray);
            	    $tableField=remove_last_field($tableField,2);
            	    $multiData=array();     
	                foreach($detailArray as $value)
	                {
	                    $dataTableField=array();
            	        $dataTableField=$this->insert_data_function($tableField,$value,$lastInsertId,$tableDetailName);
            	        $dataTableField[ucfirst($name."detail"."CDT")]=date('Y-m-d H:i:s');
            	        $dataTableField[ucfirst($name."detail"."Status")]=0;
            	        //$data=$this->mm->insert_data($tableDetailName,$dataTableField);
            	        //echo $data;
            	        array_push($multiData,$dataTableField);
	                }
	                //check_p($multiData);
	                $data=$this->mm->insert_multiple_data($tableDetailName,$multiData);
	           }
	           
	       }
	       else
	       {  //INSERT NEW DATA
              // echo "Insert Data";
             // check_p($dataTableField);
                $lastInsertId=$this->mm->insert_data($tblName,$dataTableField);
               // echo $lastInsertId;
                $tableDetailName='tbl'.$name.'detail';
                $tablePresent=$this->mm->check_table_present($tableDetailName);
                if ($tablePresent)
                {
                  //  check_p($lastInsertId);
                    $detailArray=explode(',',($_POST['DetailArray']));
	                $tableField=$this->mm->get_table_heading($tableDetailName);
            	    //check_p($tableField);
            	    $tableField=remove_last_field($tableField,2);
            	    $multiData=array();     
	                foreach($detailArray as $value)
	                {
	                    $dataTableField=array();
            	        $dataTableField=$this->insert_data_function($tableField,$value,$lastInsertId);
            	        $dataTableField[ucfirst($name."detail"."CDT")]=date('Y-m-d H:i:s');
            	        $dataTableField[ucfirst($name."detail"."Status")]=0;
            	        //$data=$this->mm->insert_data($tableDetailName,$dataTableField);
            	       ;
            	        array_push($multiData,$dataTableField);
	                  //   print_r($data)
	                    
	                }
	               
	               // check_p($multiData);
	                $data=$this->mm->insert_multiple_data($tableDetailName,$multiData);
	           }
	            $tableDetailName='tbl'.$name.'detail2';
                $tablePresent=$this->mm->check_table_present($tableDetailName);
                if ($tablePresent)
                {
                  //  check_p($lastInsertId);
                    $detailArray=explode(',',($_POST['DetailArray2']));
	                $tableField=$this->mm->get_table_heading($tableDetailName);
            	    //check_p($tableField);
            	    $tableField=remove_last_field($tableField,2);
            	    $multiData=array();     
	                foreach($detailArray as $value)
	                {
	                    $dataTableField=array();
            	        $dataTableField=$this->insert_data_function($tableField,$value,$lastInsertId);
            	        $dataTableField[ucfirst($name."detail2"."CDT")]=date('Y-m-d H:i:s');
            	        $dataTableField[ucfirst($name."detail2"."Status")]=0;
            	        //$data=$this->mm->insert_data($tableDetailName,$dataTableField);
            	       ;
            	        array_push($multiData,$dataTableField);
	                  //   print_r($data)
	                    
	                }
	               
	               // check_p($multiData);
	                $data=$this->mm->insert_multiple_data($tableDetailName,$multiData);
	           }
	           
	       }
	       //check_p($data);
	        echo  $lastInsertId;
	}
	public function insert_same_data($name = '',$detailArray='')  //inserting a data in table
	{       
	        $qry=$this->mm->get_last_query_executed();
	        echo $qry."asd"; 
	        check_p($qry);
	        
	        $colName=strtolower($name);
	        $tblName="tbl".$colName; 
	        $tableField=$this->mm->get_table_heading($tblName);
	        $tableField=remove_last_field($tableField,2);
	       // $tableField=remove_first_field($tableField);
	        $dataTableField=array();
	        $dataTableField=$this->insert_data_function($tableField);
	        $dataTableField[ucfirst($name."CDT")]=date('Y-m-d H:i:s');
	        $dataTableField[ucfirst($name."Status")]=0;
	       //check_p($this->input->post($tableField[0]));
	       if($this->input->post($tableField[0])!=NULL)
	       { //UPDATE DATA
              //  echo "Update Data";
              //check_p($this->input->post($tableField[0]));
                //check_p($dataTableField);
                $data=$this->mm->update_data($tblName,$dataTableField,$tableField[0],$this->input->post($tableField[0]));
	            $lastInsertId=$this->input->post($tableField[0]);
	            $tableDetailName='tbl'.$name.'detail';
                $tablePresent=$this->mm->check_table_present($tableDetailName);
                if ($tablePresent)
                {
                    //check_p($tableDetailName);
                    $detailArray=explode(',',($_POST['DetailArray']));
	                $tableField=$this->mm->get_table_heading($tableDetailName);
            	    //check_p($detailArray);
            	    $tableField=remove_last_field($tableField,2);
            	    $multiData=array();     
	                foreach($detailArray as $value)
	                {
	                    $dataTableField=array();
            	        $dataTableField=$this->insert_data_function($tableField,$value,$lastInsertId,$tableDetailName);
            	        $dataTableField[ucfirst($name."detail"."CDT")]=date('Y-m-d H:i:s');
            	        $dataTableField[ucfirst($name."detail"."Status")]=0;
            	        //$data=$this->mm->insert_data($tableDetailName,$dataTableField);
            	        //echo $data;
            	        array_push($multiData,$dataTableField);
	                }
	                //check_p($multiData);
	                $data=$this->mm->insert_multiple_data($tableDetailName,$multiData);
	           }
	           
	       }
	       else
	       {  //INSERT NEW DATA
              // echo "Insert Data";
             // check_p($dataTableField);
                $lastInsertId=$this->mm->insert_data($tblName,$dataTableField);
               // echo $lastInsertId;
                $tableDetailName='tbl'.$name.'detail';
                $tablePresent=$this->mm->check_table_present($tableDetailName);
                if ($tablePresent)
                {
                  //  check_p($lastInsertId);
                    $detailArray=explode(',',($_POST['DetailArray']));
	                $tableField=$this->mm->get_table_heading($tableDetailName);
            	    //check_p($tableField);
            	    $tableField=remove_last_field($tableField,2);
            	    $multiData=array();     
	                foreach($detailArray as $value)
	                {
	                    $dataTableField=array();
            	        $dataTableField=$this->insert_data_function($tableField,$value,$lastInsertId);
            	        $dataTableField[ucfirst($name."detail"."CDT")]=date('Y-m-d H:i:s');
            	        $dataTableField[ucfirst($name."detail"."Status")]=0;
            	        //$data=$this->mm->insert_data($tableDetailName,$dataTableField);
            	       ;
            	        array_push($multiData,$dataTableField);
	                  //   print_r($data)
	                    
	                }
	               // check_p($multiData);
	                $data=$this->mm->insert_multiple_data($tableDetailName,$multiData);
	           }
	       }
	       //check_p($data);
	        echo  1;
	}
	public function get_last_id($mainTblName,$tblName,$whereData)
	{   
	        $whereColumn=ucfirst(remove("tbl",$tblName)."Id");
	        $where=array($whereColumn=>$whereData);
	        $data=$this->mm->get_last_id($mainTblName,'MemberNo',$where);
            
            //check_p($data) ; 
            echo json_encode($data);
	        
	}
}
