
<section class="content">
  <div class="row">
    <div class="col-md-12"> 
            <div id="AddFormCard" class="card card-default collapsed-card card-success" >
              <div class="card-header">
                <h3 class="card-title">Add <?=ucfirst($page)?></h3>
                <div class="card-tools" >
                  <button type="button" id="AddBtn"  class="btn btn-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body" id="AddFormBody">
                <form   id="AddUpdateForm" enctype="multipart/form-data">
                  <div class="card-body">  
                        <div class="row ">
                                 
                                <?php   $filterField=remove_CDT($OriginalFields);
                                      $filterField=remove_last_field($filterField,4);
                                 ?>
                                 <input type="hidden" name='<?=$filterField[0]?>'  id='<?=$filterField[0]?>'  >
                               
                                 <?php
                                         $filterField=remove_first_field($filterField);
                                        foreach($filterField as $data)
                                        {   ?>
                                                <?= get_input_field($data)?>
                                <?php   }  ?>
                        </div>
                      <div class="modal-footer ">
                            <button type="submit" name="btnSubmit" id="btnSubmit" class="btn btn-success">Submit</button>
                      </div>
                     </div> 
                </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          </div>
</section>
