<script>
var tblName=<?=$tblName?>;
var ajaxUrl="<?=site_url('Admin/Ajax/get_all_data/')?>"+"?tblName="+tblName;
var ajaxStatusUpdateUrl="<?=site_url('Admin/Ajax/update_status/')?>"+tblName;
var ajaxGetSingleUrl="<?=site_url('Admin/Ajax/get_a_data/')?>"+tblName;
var ajaxPrintBillUrl="<?=site_url('Admin/Ajax/print_a_bill/')?>"+tblName;

 //update data from  datatable
  $(function(){
    $('#example1').on('click','tbody .updatedata',function(){
      $.ajax({
                    dataType: "json",
                  url:ajaxGetSingleUrl+"/"+$(this).attr("id"),
                  success:function(result)
                  {
                 //     alert(result[0]['SalesId']);
                  //    $('#ProductName').val(result[0]['ProductName']);
                    //  $('#example1').DataTable().ajax.reload();
                              
                       
                   //  $("AddFormCard").removeClass("intro");
                     $('#AddFormCard').css("card card-default card-success");
                     $('#AddFormCard').removeClass("collapsed-card");
                     $('#AddFormBody').css("display", "block");
                        <?= $ajaxSucessData ?>
                  },
            });
     });
  });
  $(function(){
    $('#example1').on('click','tbody .togglestatus',function(){
      $.ajax({
                   dataType: "json",
                  url:ajaxStatusUpdateUrl+"/"+$(this).attr("id"),
                  success:function(result)
                  {
                     // alert("asd");
                      $('#example1').DataTable().ajax.reload(); 
                  },
            });
     });
  });
  // print bill 
  $(function(){
    $('#example1').on('click','tbody .printbill',function(){
      $.ajax({
                   dataType: "json",
                  url:ajaxPrintBillUrl+"/"+$(this).attr("id"),
                  success:function(result)
                  {
                  
                    $('#BillCard').css("card card-default card-warning");
                    $('#BillCard').removeClass("collapsed-card");
                    $('#BillBody').css("display", "block");
                 
                      <?=$ajaxSucessJoinData?>
                  },
            });
     });
  });
var ajaxUrl="<?=site_url('Admin/Ajax/get_all_data/')?>"+"?tblName="+tblName;
  $(function () {
    $('#example1').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
        "scrollX": true,
        "scrollY": true,
        "ajax":{
            
        url :ajaxUrl,
        dataSrc:"datasource",
        },
        
        aoColumns:
        <?= $aocolumns?>
    });
  });
  $(function(){
    $('#StateID').on('change',function(){
      $.ajax({
        url:"<?=site_url('Category/get_city/')?>"+$(this).val(),
        success:function(result){
          $('#CityID').html(result);
        }
      });
    });
    
  });
</script>

