 <script>
 $(document).ready( function() {
       var tax="";
        var GstNo="";
    $('#PurchaseId').on('change',function(){
        var Id = $(this).val();
        var tableName="tblpurchase";
        var ajaxGetSingleUrl1="<?=site_url('Admin/Ajax/get_a_data_purchase_custom/')?>"+tableName+"/"+Id;
        $.ajax({
            type:'POST',
            url:ajaxGetSingleUrl1,
            //data:formData,
            cache:false,
            contentType: false,
            processData: false,
            dataType:"JSON",
            success:function(result){
                $('#SalesBasic').val(result['PurchaseBasicFare']);
                $('#SalesYq').val(result['PurchaseYqFare']);
                $('#SalesTravelDate').val(result['PurchaseTravelDate']);
                tax=parseFloat(result['HsnTax']);
            },
        });
    });        
    $('#CustomerId').on('change',function(){
        var Id = $(this).val();
        var tableName="tblcustomer";
        var ajaxGetSingleUrl1="<?=site_url('Admin/Ajax/get_a_data/')?>"+tableName+"/"+Id;
        $.ajax({
            type:'POST',
            url:ajaxGetSingleUrl1,
            //data:formData,
            cache:false,
            contentType: false,
            processData: false,
            dataType:"JSON",
            success:function(result){
                    GstNo=result[0]['CustomerGSTNo'];
                    
            },
        });
    });        
    
    var d = new Date();
    var month = d.getMonth()+1;
    var day = d.getDate();
    var output =   month + '/' + day+ '/' +d.getFullYear();
    $('#SalesDate').val(output);
    $('#SalesGrossTotal').focus(function(){
        
        var SalesBasic=$('#SalesBasic').val();
        var SalesK3Tax=$('#SalesK3Tax').val();
        var SalesYq=$('#SalesYq').val();
        var SalesOther=$('#SalesOther').val();
        var tot=parseFloat(SalesBasic)+parseFloat(SalesK3Tax)+parseFloat(SalesYq)+parseFloat(SalesOther);
         $('#SalesGrossTotal').val(tot);
    });
    $('#SalesBasic').val(0);
    $('#SalesK3Tax').val(0);
    $('#SalesYq').val(0);
    $('#SalesOther').val(0);
    $('#SalesGrossTotal').val(0);
    $('#SalesIGST').val(0);
    $('#SalesSGST').val(0);
    $('#SalesCGST').val(0);
    $('#SalesProcessingCharges').val(0);
    $('#SalesReverseCharge').val("No");
    /*$('#SalesIGST').hide();  
    $('#LabelSalesIGST').hide();*/
    $('#SalesProcessingCharges').focusout(function(){
       if(GstNo)
       {
            GstNo=GstNo.substr(0,2);
            var SPC=$('#SalesProcessingCharges').val();
            if(GstNo=="24")
            {  //in gujrat
                $('#SalesCGST').show();  
                $('#LabelSalesCGST').show();
                $('#SalesSGST').show();  
                $('#LabelSalesSGST').show();
                $('#SalesIGST').hide();  
                $('#LabelSalesIGST').hide();
                tax=(tax/2).toFixed(2);
                var CGST=(tax/100).toFixed(2)*parseFloat(SPC);
                var SGST=(tax/100).toFixed(2)*parseFloat(SPC);
                $('#SalesCGST').val(CGST);  
                $('#SalesSGST').val(SGST);  
                
                
            }
            else
            {   // not in gujarat
                $('#SalesIGST').show();  
                $('#LabelSalesIGST').show();
                $('#SalesCGST').hide();  
                $('#LabelSalesCGST').hide();
                $('#SalesSGST').hide();  
                $('#LabelSalesSGST').hide();
                //alert(tax);
                var IGST=(tax/100).toFixed(2)*parseFloat(SPC);
                $('#SalesIGST').val(IGST);  
                //alert(IGST);
            }
       }
       else
       { // no gst
           
       }
    });
    $('#SalesTotal').focus(function(){
  
        var SalesGrossTotal=check($('#SalesGrossTotal').val());
        var SalesIGST=$('#SalesIGST').val();
        var SalesSGST=$('#SalesSGST').val();
        var SalesCGST=$('#SalesCGST').val();
        var SalesProcessingCharges=$('#SalesProcessingCharges').val();
        
        var salestot=parseFloat(SalesGrossTotal)+parseFloat(SalesIGST)+parseFloat(SalesSGST)+parseFloat(SalesCGST)+parseFloat(SalesProcessingCharges);
    
         $('#SalesTotal').val(salestot.toFixed(2));
    });
    
}); 
function check($var)
{
    if($var)
    {
        //alert("Nan hai");
        return $var;
    }
    else
    {   return 0;
    }
}
</script>