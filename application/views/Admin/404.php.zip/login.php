<?php  $baseUrl=base_url('resources/assets/'); ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Web N App Maker</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
 <link rel="stylesheet" href="<?=$baseUrl?>plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=$baseUrl?>dist/css/adminlte.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?=$baseUrl?>plugins/iCheck/square/blue.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <style type="text/css">
    .input-span{
      height: 50px;
      width:50px;
      background: blue;
      display: block;
      border-radius: 50%;
      text-align: center;
      color: white;
      position: absolute;
      right: 0;
      right:.5rem;
      box-shadow: 5px 0 10px rgba(0,0,0,.2);
    }
    .input{
      height: 3.2rem;
      border-radius: 10px;
      box-shadow: 0 0 5px rgba(0,0,0,.2);
    }
  </style>
</head>

<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="<?=COMPANY_LINK?>"><b><?php echo  COMPANY_NAME ?></b> </a>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in</p>
      <form action="<?=site_url('Admin/Dashboard/login/');?>" method="post">
        <div class="form-group">
     <!--     <label><input type="radio" name="loginwith" value="Complaint" checked> Admin </label>
     --> <!--    <label><input type="radio" name="loginwith" value="Service"> Employee </label>
      -->  </div>
        <div class="form-group has-feedback">
          <span class="fa fa-envelope form-control-feedback input-span" style="line-height: 50px;"></span>
          <input type="email" class="form-control input" name=Admin_Email placeholder="Email">
        </div>
        <div class="form-group has-feedback">
          <span class="fa fa-lock form-control-feedback input-span" style="line-height: 50px;"></span>
          <input type="password" class="form-control input" name="Admin_Password" placeholder="Password">
        </div>
        <div class="row">
          <div class="col-8">
            <!-- <div class="checkbox icheck">
              <label>
                <input type="checkbox"> Remember Me
              </label>
            </div> -->
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" name="btnsubmit" class="btn btn-primary btn-block btn-flat" style="box-shadow: 0 0 10px rgba(0,0,0,.2);background: blue;border-radius: 5px;">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

      <!-- <div class="social-auth-links text-center mb-3">
        <p>- OR -</p>
        <a href="#" class="btn btn-block btn-primary">
          <i class="fa fa-facebook mr-2"></i> Sign in using Facebook
        </a>
        <a href="#" class="btn btn-block btn-danger">
          <i class="fa fa-google-plus mr-2"></i> Sign in using Google+
        </a>
      </div> -->
      <!-- /.social-auth-links -->

     <!--  <p class="mb-1">
        <a href="#">I forgot my password</a>
      </p>
      <p class="mb-0">
        <a href="register.html" class="text-center">Register a new membership</a>
      </p> -->
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?=$baseUrl?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?=$baseUrl?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- iCheck -->
<script src="<?=$baseUrl?>plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass   : 'iradio_square-blue',
      increaseArea : '20%' // optional
    })
  })
</script>
</body>
</html>
