<script type="text/javascript">
        
/*    $(function(){
    $('#example1').on('click','tbody .togglestatus',function(){
      $.ajax({
      url:"<?=site_url('Admin/Ajax/insert_data/');?>"++$(this).attr("id"),success:function(result){ $('#data_table').DataTable().ajax.reload(); }
      });
      
    });
  });*/

 $(function(){
     $('#DownloadExcel').on('click',function(){
        var tblName = '<?=$page?>';
        var formData = new FormData(this);

        $.ajax({
            type:'POST',
            url:"<?=site_url('Admin/Dashboard/CreateExcel/');?>"+tblName,
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
               if(data==1)
                {
                        $('#example1').DataTable().ajax.reload();
                        $('#AddUpdateForm')[0].reset();
                        $('#AddFormBody').css("display", "none");
                        
                    
                }   
            
            },
        });
     });
 });
    
//add new data of AddUpdateForm
    $('#AddUpdateForm').on('submit',(function(e) {
        var tblName = '<?=$page?>';
        var formData = new FormData(this);
        
        e.preventDefault();
        $.ajax({
            type:'POST',
            url:"<?=site_url('Admin/Ajax/insert_data/');?>"+tblName,
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
               if(data==1)
                {
                        $('#example1').DataTable().ajax.reload();
                        $('#AddUpdateForm')[0].reset();
                        $('#AddFormBody').css("display", "none");
                        
                    
                }   
            
            },
        });
    }));
//add new excel csv  of ImportCSVForm
    $('#CSVForm').on('submit',(function(e) {
        var tblName = '<?=$page?>';
        var formData = new FormData(this);
        
        e.preventDefault();
        $.ajax({
            type:'POST',
            url:"<?=site_url('Admin/Ajax/import_CSV/');?>"+tblName,
            data:formData,
            cache:false,
            contentType: false,
            processData: false,
            success:function(data){
               if(data==1)
                {
                        $('#example1').DataTable().ajax.reload();
                        $('#CSVForm')[0].reset();
                        $('#CSVBody').css("display", "none");
                }  
            },
        });
    }));    
</script>