<script>
$(document).ready(function(){
  $("#AddBtn").click(function(){
    var tblName = '<?=$page?>';
      $.ajax({
        url:"<?=site_url('Admin/Ajax/get_data/')?>"+tblName,
        dataType:"json",
         success:function(response)
             {  
               /*  for(test in response["tblcategory"])
                 { 
                 //alert(response["tblcategory"][test].CategoryName);
                  }// $('#StateName').append('<option value="'+response['tblstate']['StateName']+'"></option>');
                */
             }      
        });
       
      });
    
  });
</script>