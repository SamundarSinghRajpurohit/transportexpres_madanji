   <footer class="main-footer">
    <strong>Copyright &copy; 2014-2018 <a href="<?=COMPANY_LINK?>"><?=COMPANY_NAME?></a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
     
    </div>
  </footer>

  </div>
</body>
</html>