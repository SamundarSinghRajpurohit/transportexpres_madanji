<aside class="main-sidebar sidebar-dark-primary elevation-4 admin-custom-color-opp ">
    <!-- Brand Logo -->
    <a href="#" class="brand-link admin-custom-color-sidebar">
      <!--<img src="http://webnappmaker.in/Balaji/resources/LOGO.png" style="height:100px; width:40px;" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">-->
      <!--<span class="brand-text font-weight-light">BALAJI</span>-->
      <span class="brand-text font-weight-light">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
          <!--<img src="http://webnappmaker.in/Balaji/resources/LOGO.png" style="height:150px; width:200px;" 
           style="opacity: .8">-->
           
    </a>

    <div class="sidebar">
      
      <nav class="mt-2">
      	<span class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false" >

            <span class="nav-item ">
                <a href="<?=base_url('/Admin/Dashboard')?>" class="nav-link  admin-custom-color-sidebar ">
                <!-- <i> <img src="https://webnappmaker.in/Balaji/resources/Icons/image_1.png"></i> -->
                <i class="fa fa-home" style="font-size:24px;color:black;"></i>
                <p class="sidebar-text">Dashboard</p>
                </a>
            </span>
            <span class="nav-item ">
                <a href="<?=base_url('/Admin/AdminDifferent')?>" class="nav-link  admin-custom-color-sidebar ">
                 <i class="fa fa-user" aria-hidden="true" style="font-size:24px;color:black;"></i>
                   <p class="sidebar-text">Admin</p>
                </a>
            </span>
            <span class="nav-item ">
                <a href="<?=base_url('/Admin/Dashboard')?>"  class="nav-link  admin-custom-color-sidebar ">
                   <i class="fa fa-user-md" style="font-size:24px;color:black;"></i>
                <p class="sidebar-text">User</p>
                <i class="right fa fa-angle-down"  aria-hidden="true"></i>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?=base_url('/Admin/CustomerDifferent')?>" class="nav-link admin-custom-color-sidebar">
                        <p class="inner-nav">Doctor</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?=base_url('/Admin/MedicalDifferent')?>" class="nav-link admin-custom-color-sidebar">
                        <p class="inner-nav">Medical Store</p>
                        </a>
                    </li>
                    
                </ul>
            </span>
            <span class="nav-item ">
                <a href="#" class="nav-link  admin-custom-color-sidebar ">
                <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:24px;color:black;"></i>
                <p class="sidebar-text">Products</p>
                <i class="right fa fa-angle-down" aria-hidden="true"></i>
                </a>
                <ul class="nav nav-treeview">   
                    <li class="nav-item">
                        <a href="<?=base_url('/Admin/CategoryDifferent')?>" class="nav-link admin-custom-color-sidebar">
                        <p class="inner-nav">Category</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?=base_url('/Admin/SubcategoryDifferent')?>" class="nav-link admin-custom-color-sidebar">
                        <p class="inner-nav">Sub-Category</p>
                        </a>
                    </li>
                    <!--<li class="nav-item">
                        <a href="http://webnappmaker.in/Balaji/Admin/HSNDifferent" class="nav-link admin-custom-color-sidebar">
                        <p class="inner-nav">HSN</p>
                        </a>
                    </li>-->
                    <li class="nav-item">
                        <a href="<?=base_url('/Admin/ProductDifferent')?>" class="nav-link admin-custom-color-sidebar">
                        <p class="inner-nav">Products</p>
                        </a>
                    </li>
                </ul>
            </span>
            <span class="nav-item ">
                <a href="<?=base_url('/Admin/purchase')?>" class="nav-link  admin-custom-color-sidebar ">
                 <i class="fa fa-book" aria-hidden="true" style="font-size:24px;color:black;"></i>
                   <p class="sidebar-text">Purchase</p>
                </a>
            </span>
            <span class="nav-item ">
                <a href="<?=base_url('/Admin/HSNDifferent')?>" class="nav-link  admin-custom-color-sidebar ">
                 <i class="fa fa-barcode" aria-hidden="true" style="font-size:24px;color:black;"></i>
                   <p class="sidebar-text">HSN</p>
                </a>
            </span>
            <span class="nav-item ">
                <a href="<?=base_url('/Admin/VenderDifferent')?>" class="nav-link  admin-custom-color-sidebar ">
                 <i class="fa fa-industry" aria-hidden="true" style="font-size:24px;color:black;"></i>
                   <p class="sidebar-text">Vender</p>
                </a>
            </span>
           <!-- <span class="nav-item ">
                <a href="</?=base_url('/Admin/PurchaseDifferent')?>" class="nav-link  admin-custom-color-sidebar ">
                 <i class="fa fa-industry" aria-hidden="true" style="font-size:24px;color:black;"></i>
                   <p class="sidebar-text">Purchase</p>
                </a>
            </span>-->
            
            <span class="nav-item ">
                <a href="<?=base_url('/Admin/Dashboard')?>"  class="nav-link  admin-custom-color-sidebar ">
                   <i class="fa fa-bank" style="font-size:24px;color:black;"></i>
                <p class="sidebar-text">Accounts</p>
                <i class="right fa fa-angle-down"  aria-hidden="true"></i>
                </a>
            <ul class="nav nav-treeview"> 
             <li class="nav-item">
              <a href="<?=site_url('Admin/Dashboard/AccountingDifferent')?>" class="nav-link admin-custom-color-sidebar">
                <i class="fa fa-bank  mr-2"></i>Accounts Receipt/Payment
              </a>
              </li>
              <li class="nav-item">
              <a href="<?=site_url('Admin/Dashboard/LedgerDifferent')?>" class="nav-link admin-custom-color-sidebar">
                <i class="fa fas fa-columns mr-2"></i>Ledger
              </a>
              </li>
              <li class="nav-item">
              <a href="<?=site_url('Admin/Dashboard/BankLedgerDifferent')?>" class="nav-link admin-custom-color-sidebar">
                <i class="fa fas fa-columns mr-2"></i>Bank Ledger
              </a>
              </li>
              <li class="nav-item">
              <a href="<?=site_url('Admin/Dashboard/CashLedgerDifferent')?>" class="nav-link admin-custom-color-sidebar">
                <i class="fa fas fa-columns mr-2"></i>Cash Ledger
              </a
              </li>
             </ul>
            <span class="nav-item ">
                <a href="<?=base_url('/Admin/Dashboard')?>" class="nav-link  admin-custom-color-sidebar ">
                <i class="fa fa-cog" aria-hidden="true" style="font-size:24px;color:black;" ></i>
                <p class="sidebar-text">Setting</p> 
                <i class="right fa fa-angle-down" aria-hidden="true"></i>
                </a>
                <ul class="nav nav-treeview">   
                    <li class="nav-item">
                        <a href="<?=base_url('/Admin/BannerDifferent')?>" class="nav-link admin-custom-color-sidebar">
                        <p class="inner-nav">Banners</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?=base_url('/Admin/BonusDifferent')?>" class="nav-link admin-custom-color-sidebar">
                        <p class="inner-nav">Bonus</p>
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a href="http://webnappmaker.in/Balaji/Admin/FAQDifferent" class="nav-link admin-custom-color-sidebar">
                        <p class="inner-nav">FAQ</p>
                        </a>
                    </li>
                    
                </ul>
              
            </span>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>